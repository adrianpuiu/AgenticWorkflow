import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { MonthlyOverview } from './components/MonthlyOverview';
import { AIInsights } from './components/AIInsights';
import { TransactionList } from './components/TransactionList';
import { DailySpendingChart } from './components/DailySpendingChart';
import { FileUpload } from './components/FileUpload';
import { ExpenseAnalytics } from './components/expense-tracking/ExpenseAnalytics';
import { IncomeAnalytics } from './components/income-analysis/IncomeAnalytics';
import { CustomChartGenerator } from './components/custom-charts/CustomChartGenerator';
import { Transaction, MonthlyStats } from './types';
import { parseEuropeanNumber, parseCSVLine, calculateMonthlyStats } from './utils/formatters';

function App() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [error, setError] = useState<string | null>(null);
  const [activeCharts, setActiveCharts] = useState(['daily-activity', 'expense-breakdown']);

  const loadTransactions = (content: string) => {
    try {
      const lines = content.split('\n').filter(line => line.trim());
      const headers = lines[0].split(';');
      
      const parsedTransactions: Transaction[] = lines.slice(1).map(line => {
        const values = parseCSVLine(line);
        return {
          transactionDate: values[0].replace(/"/g, ''),
          bookingDate: values[1].replace(/"/g, ''),
          accountNumber: values[2].replace(/"/g, ''),
          accountName: values[3].replace(/"/g, ''),
          transactionCategory: values[4].replace(/"/g, ''),
          accountNumberCard: values[5].replace(/"/g, ''),
          nameOfAccount: values[6].replace(/"/g, ''),
          transactionType: values[7].replace(/"/g, ''),
          message: values[8].replace(/"/g, ''),
          note: values[9].replace(/"/g, ''),
          vs: values[10].replace(/"/g, ''),
          ks: values[11].replace(/"/g, ''),
          ss: values[12].replace(/"/g, ''),
          bookedAmount: parseEuropeanNumber(values[13]),
          accountCurrency: values[14].replace(/"/g, ''),
          originalAmount: values[15].replace(/"/g, ''),
          originalCurrency: values[16].replace(/"/g, ''),
          fee: values[17].replace(/"/g, ''),
          transactionId: values[18].replace(/"/g, ''),
          merchant: values[20]?.replace(/"/g, '') || '',
          city: values[21]?.replace(/"/g, '') || '',
        };
      });

      setTransactions(parsedTransactions);
      setError(null);

      // Set current month to the most recent transaction date
      if (parsedTransactions.length > 0) {
        const [day, month, year] = parsedTransactions[0].transactionDate.split('.');
        setCurrentMonth(new Date(parseInt(year), parseInt(month) - 1, parseInt(day)));
      }
    } catch (err) {
      setError('Failed to parse the transaction data. Please try again.');
      console.error('Data parsing error:', err);
    }
  };

  useEffect(() => {
    // Load initial mock data
    fetch('/transactions.csv')
      .then(response => response.text())
      .then(loadTransactions)
      .catch(err => {
        setError('Failed to load transaction data. Please try again.');
        console.error('Data loading error:', err);
      });
  }, []);

  const handleMonthChange = (delta: number) => {
    setCurrentMonth(prevMonth => {
      const newMonth = new Date(prevMonth);
      newMonth.setMonth(newMonth.getMonth() + delta);
      return newMonth;
    });
  };

  // Calculate monthly stats
  const stats = calculateMonthlyStats(transactions, currentMonth);

  // Filter transactions for current month
  const currentMonthTransactions = transactions.filter(t => {
    const [day, month, year] = t.transactionDate.split('.');
    const transactionDate = new Date(parseInt(year), parseInt(month) - 1, parseInt(day));
    return transactionDate.getMonth() === currentMonth.getMonth() &&
           transactionDate.getFullYear() === currentMonth.getFullYear();
  });

  return (
    <div className="min-h-screen">
      <div className="max-w-[1600px] mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Transaction Analysis</h1>
          
          <div className="flex items-center gap-4">
            <button
              onClick={() => handleMonthChange(-1)}
              className="p-2 hover:bg-white/10 rounded-full transition-colors"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            
            <span className="text-lg font-medium">
              {currentMonth.toLocaleString('default', { month: 'long', year: 'numeric' })}
            </span>
            
            <button
              onClick={() => handleMonthChange(1)}
              className="p-2 hover:bg-white/10 rounded-full transition-colors"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        <FileUpload onFileUpload={loadTransactions} />

        {error ? (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4">
            <p className="text-red-700">{error}</p>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Monthly Overview - Full Width */}
            <div className="grid grid-cols-12 gap-6">
              <div className="col-span-12">
                <MonthlyOverview stats={stats} currentMonth={currentMonth} />
              </div>
            </div>
            
            {/* Main Content Grid */}
            <div className="grid grid-cols-12 gap-6">
              {/* Left Column - Charts */}
              <div className="col-span-12 lg:col-span-8 space-y-6">
                <DailySpendingChart 
                  transactions={transactions}
                  currentMonth={currentMonth}
                />
                
                {activeCharts.includes('expense-breakdown') && (
                  <ExpenseAnalytics transactions={currentMonthTransactions} />
                )}
                
                {activeCharts.includes('income-analysis') && (
                  <IncomeAnalytics transactions={currentMonthTransactions} />
                )}

                {activeCharts.includes('custom-chart') && (
                  <CustomChartGenerator transactions={currentMonthTransactions} />
                )}
              </div>
              
              {/* Right Column - AI Insights & Transactions */}
              <div className="col-span-12 lg:col-span-4 space-y-6">
                <AIInsights 
                  spending={stats.spending}
                  income={stats.income}
                  highestCategory={{
                    name: stats.highestCategory.category,
                    amount: stats.highestCategory.amount
                  }}
                  transactions={currentMonthTransactions}
                />
                
                {activeCharts.includes('recent-transactions') && (
                  <TransactionList transactions={currentMonthTransactions} />
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;