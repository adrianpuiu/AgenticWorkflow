// Color palette for charts
export const CHART_COLORS = {
  primary: ["#54bebe", "#76c8c8", "#98d1d1", "#badbdb", "#dedad2", "#e4bcad", "#df979e", "#d7658b", "#c80064"],
  
  // Specific colors for different chart types
  income: "#54bebe",     // Teal
  expense: "#d7658b",    // Pink
  balance: "#98d1d1",    // Light teal
  
  // Category colors
  categories: {
    'Card Payment': "#54bebe",      // Teal
    'Standing order': "#c80064",    // Deep pink
    'ATM withdrawal': "#e4bcad",    // Peach
    'Fee': "#df979e",              // Light pink
    'Investment': "#76c8c8",       // Light teal
    'Subscription': "#dedad2",     // Light gray
    'Entertainment': "#d7658b",    // Pink
    'Food': "#98d1d1",            // Medium teal
    'Other': "#badbdb"            // Very light teal
  },
  
  // Income source colors
  incomeSources: {
    'Salary': "#54bebe",          // Teal
    'Investment': "#c80064",      // Deep pink
    'Interest': "#98d1d1",        // Light teal
    'Freelance': "#e4bcad",       // Peach
    'Other': "#df979e"           // Light pink
  },
  
  // Transaction types
  transactionTypes: {
    'Card payment': "#54bebe",    // Teal
    'Standing order': "#c80064",  // Deep pink
    'ATM withdrawal': "#98d1d1",  // Light teal
    'Interest payment': "#e4bcad", // Peach
    'Incoming payment': "#76c8c8", // Medium teal
    'Fee': "#df979e",            // Light pink
    'Other': "#dedad2"           // Light gray
  }
};