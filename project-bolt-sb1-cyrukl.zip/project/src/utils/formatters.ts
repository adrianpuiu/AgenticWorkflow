import { Transaction } from '../types';

export const formatCurrency = (amount: number, currency: string = 'CZK'): string => {
  return new Intl.NumberFormat('cs-CZ', {
    style: 'currency',
    currency,
    minimumFractionDigits: 2,
  }).format(amount);
};

export const parseEuropeanNumber = (value: string): number => {
  if (!value) return 0;
  
  // Remove quotes and whitespace
  const cleanValue = value.replace(/["\s]/g, '');
  if (!cleanValue) return 0;
  
  // Handle European number format (1.234,56 or -1.234,56)
  const normalizedValue = cleanValue
    .replace(/\./g, '') // Remove thousand separators
    .replace(',', '.'); // Convert decimal separator to dot
    
  const result = parseFloat(normalizedValue);
  return isNaN(result) ? 0 : result;
};

export const parseCSVLine = (line: string): string[] => {
  const result: string[] = [];
  let inQuotes = false;
  let currentValue = '';
  
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    const nextChar = line[i + 1];
    
    if (char === '"') {
      if (inQuotes && nextChar === '"') {
        // Handle escaped quotes
        currentValue += '"';
        i++; // Skip next quote
      } else {
        // Toggle quotes mode
        inQuotes = !inQuotes;
      }
    } else if (char === ';' && !inQuotes) {
      // End of field
      result.push(currentValue);
      currentValue = '';
    } else {
      currentValue += char;
    }
  }
  
  // Add the last field
  result.push(currentValue);
  
  return result;
};

export const getMerchantName = (transaction: Transaction): string => {
  if (transaction.merchant && transaction.merchant.trim() !== '') {
    return transaction.merchant;
  }
  
  if (transaction.message) {
    // Extract merchant name from message (format: "name; location; country")
    const parts = transaction.message.split(';');
    if (parts[0]) {
      // Remove currency amounts if present (e.g., "24,21 USD;ANTHROPIC")
      const cleanPart = parts[0].replace(/^[\d,.]+ ?(RON|EUR|USD|CZK)\s*;?\s*/, '').trim();
      return cleanPart || 'Unknown';
    }
  }
  
  return 'Unknown';
};

export const getTransactionDate = (dateStr: string): Date => {
  const [day, month, year] = dateStr.split('.').map(Number);
  return new Date(year, month - 1, day);
};

export const calculateMonthlyStats = (transactions: Transaction[], currentMonth: Date) => {
  // Filter transactions for current month
  const monthTransactions = transactions.filter(t => {
    const [day, month, year] = t.transactionDate.split('.').map(Number);
    const transactionDate = new Date(year, month - 1, day);
    return transactionDate.getMonth() === currentMonth.getMonth() &&
           transactionDate.getFullYear() === currentMonth.getFullYear();
  });

  const income = monthTransactions
    .filter(t => t.bookedAmount > 0)
    .reduce((sum, t) => sum + t.bookedAmount, 0);

  const spending = Math.abs(monthTransactions
    .filter(t => t.bookedAmount < 0)
    .reduce((sum, t) => sum + t.bookedAmount, 0));

  const balance = monthTransactions.reduce((sum, t) => sum + t.bookedAmount, 0);

  // Get highest spending category
  const categorySpending = monthTransactions
    .filter(t => t.bookedAmount < 0)
    .reduce((acc, t) => {
      const category = t.transactionCategory || 'Unknown';
      acc[category] = (acc[category] || 0) + Math.abs(t.bookedAmount);
      return acc;
    }, {} as Record<string, number>);

  const highestCategory = Object.entries(categorySpending)
    .reduce((max, [category, amount]) => 
      amount > max.amount ? { category, amount } : max,
      { category: 'Unknown', amount: 0 }
    );

  // Calculate daily averages
  const daysInMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 0).getDate();
  const averageDailyEarnings = income / daysInMonth;
  const averageDailySpending = spending / daysInMonth;

  return {
    income,
    spending,
    balance,
    highestCategory,
    averageDailyEarnings,
    averageDailySpending,
    daysInMonth
  };
};

export const groupTransactionsByDay = (transactions: Transaction[], currentMonth: Date) => {
  const monthTransactions = transactions.filter(t => {
    const [day, month, year] = t.transactionDate.split('.').map(Number);
    const transactionDate = new Date(year, month - 1, day);
    return transactionDate.getMonth() === currentMonth.getMonth() &&
           transactionDate.getFullYear() === currentMonth.getFullYear();
  });

  return monthTransactions.reduce((acc, t) => {
    const date = t.transactionDate;
    acc[date] = (acc[date] || 0) + Math.abs(t.bookedAmount);
    return acc;
  }, {} as Record<string, number>);
}