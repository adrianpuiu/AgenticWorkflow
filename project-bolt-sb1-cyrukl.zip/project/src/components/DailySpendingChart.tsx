import React, { useMemo, useState } from 'react';
import { format, eachDayOfInterval, startOfMonth, endOfMonth } from 'date-fns';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { Transaction } from '../types';
import { formatCurrency } from '../utils/formatters';
import { CHART_COLORS } from '../utils/colors';

interface Props {
  transactions: Transaction[];
  currentMonth: Date;
}

interface CustomTooltipProps {
  active?: boolean;
  payload?: Array<{ name: string; value: number; stroke: string }>;
  label?: string;
}

const CustomTooltip: React.FC<CustomTooltipProps> = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;

  const income = payload.find(p => p.name === 'Income')?.value || 0;
  const spending = Math.abs(payload.find(p => p.name === 'Spending')?.value || 0);
  const balance = payload.find(p => p.name === 'Balance')?.value || 0;

  return (
    <div className="bg-white/90 backdrop-blur-sm p-4 shadow-lg rounded-lg border border-white/20">
      <p className="font-medium text-gray-900 mb-2">{label}</p>
      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: CHART_COLORS.income }} />
          <p className="text-sm">Income: {formatCurrency(income)}</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: CHART_COLORS.expense }} />
          <p className="text-sm">Spending: {formatCurrency(spending)}</p>
        </div>
        <div className="pt-2 border-t border-gray-200">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: CHART_COLORS.balance }} />
            <p className="text-sm font-medium">
              Balance: {formatCurrency(balance)}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

const CustomLegend: React.FC<any> = ({ payload }) => {
  return (
    <div className="flex flex-wrap justify-center gap-6 mt-4">
      {payload.map((entry: any, index: number) => (
        <div key={`item-${index}`} className="flex items-center gap-2">
          <div 
            className="w-3 h-3 rounded-full" 
            style={{ backgroundColor: entry.color }}
          />
          <span className="text-sm text-gray-600">{entry.value}</span>
        </div>
      ))}
    </div>
  );
};

export const DailySpendingChart: React.FC<Props> = ({ transactions, currentMonth }) => {
  const [opacity, setOpacity] = useState({
    Income: 1,
    Spending: 1,
    Balance: 1
  });

  const dailyData = useMemo(() => {
    const monthInterval = {
      start: startOfMonth(currentMonth),
      end: endOfMonth(currentMonth)
    };

    const days = eachDayOfInterval(monthInterval);
    let runningBalance = 0;

    return days.map(day => {
      const dayStr = format(day, 'dd.MM.yyyy');
      const dayTransactions = transactions.filter(t => t.transactionDate === dayStr);
      
      const income = dayTransactions
        .filter(t => t.bookedAmount > 0)
        .reduce((sum, t) => sum + t.bookedAmount, 0);
      
      const spending = Math.abs(dayTransactions
        .filter(t => t.bookedAmount < 0)
        .reduce((sum, t) => sum + t.bookedAmount, 0));

      runningBalance += income - spending;

      return {
        date: format(day, 'MMM d'),
        Income: income,
        Spending: -spending, // Make spending negative for better visualization
        Balance: runningBalance
      };
    });
  }, [transactions, currentMonth]);

  const handleMouseEnter = (o: any) => {
    const { dataKey } = o;
    setOpacity({
      ...opacity,
      [dataKey]: 0.5
    });
  };

  const handleMouseLeave = (o: any) => {
    const { dataKey } = o;
    setOpacity({
      ...opacity,
      [dataKey]: 1
    });
  };

  return (
    <div className="chart-container p-6">
      <h3 className="text-lg font-semibold mb-4">Daily Financial Activity</h3>
      <div className="h-[400px]">
        <ResponsiveContainer>
          <AreaChart 
            data={dailyData} 
            margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
          >
            <defs>
              <linearGradient id="colorIncome" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={CHART_COLORS.income} stopOpacity={0.8}/>
                <stop offset="95%" stopColor={CHART_COLORS.income} stopOpacity={0.1}/>
              </linearGradient>
              <linearGradient id="colorSpending" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={CHART_COLORS.expense} stopOpacity={0.8}/>
                <stop offset="95%" stopColor={CHART_COLORS.expense} stopOpacity={0.1}/>
              </linearGradient>
              <linearGradient id="colorBalance" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={CHART_COLORS.balance} stopOpacity={0.8}/>
                <stop offset="95%" stopColor={CHART_COLORS.balance} stopOpacity={0.1}/>
              </linearGradient>
            </defs>
            
            <CartesianGrid 
              strokeDasharray="3 3" 
              stroke="rgba(255,255,255,0.2)" 
              vertical={false}
            />
            
            <XAxis 
              dataKey="date"
              tick={{ fontSize: 12, fill: '#666' }}
              stroke="#9ca3af"
              tickLine={false}
            />
            
            <YAxis 
              tickFormatter={(value) => formatCurrency(Math.abs(value)).split('CZK')[0].trim()}
              stroke="#9ca3af"
              tickLine={false}
              axisLine={false}
            />
            
            <Tooltip content={<CustomTooltip />} />
            <Legend content={<CustomLegend />} />

            <Area
              type="monotone"
              dataKey="Income"
              stroke={CHART_COLORS.income}
              fill="url(#colorIncome)"
              strokeWidth={2}
              fillOpacity={opacity.Income}
              onMouseEnter={handleMouseEnter}
              onMouseLeave={handleMouseLeave}
              activeDot={{ r: 6, strokeWidth: 2 }}
            />
            
            <Area
              type="monotone"
              dataKey="Spending"
              stroke={CHART_COLORS.expense}
              fill="url(#colorSpending)"
              strokeWidth={2}
              fillOpacity={opacity.Spending}
              onMouseEnter={handleMouseEnter}
              onMouseLeave={handleMouseLeave}
              activeDot={{ r: 6, strokeWidth: 2 }}
            />
            
            <Area
              type="monotone"
              dataKey="Balance"
              stroke={CHART_COLORS.balance}
              fill="url(#colorBalance)"
              strokeWidth={2}
              fillOpacity={opacity.Balance}
              onMouseEnter={handleMouseEnter}
              onMouseLeave={handleMouseLeave}
              activeDot={{ r: 6, strokeWidth: 2 }}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};