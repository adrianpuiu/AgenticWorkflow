import React, { useState } from 'react';
import { format } from 'date-fns';
import { ChevronLeft, ChevronRight, Receipt, Search, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { Transaction } from '../types';
import { formatCurrency, getMerchantName } from '../utils/formatters';
import { CHART_COLORS } from '../utils/colors';

interface Props {
  transactions: Transaction[];
}

export const TransactionList: React.FC<Props> = ({ transactions }) => {
  const [page, setPage] = useState(0);
  const [search, setSearch] = useState('');
  const pageSize = 8;

  const filteredTransactions = transactions.filter(t => 
    getMerchantName(t).toLowerCase().includes(search.toLowerCase()) ||
    t.transactionCategory?.toLowerCase().includes(search.toLowerCase()) ||
    t.message?.toLowerCase().includes(search.toLowerCase())
  );
  
  const totalPages = Math.ceil(filteredTransactions.length / pageSize);
  const paginatedTransactions = filteredTransactions.slice(page * pageSize, (page + 1) * pageSize);

  return (
    <div className="chart-container overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-white/10 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Receipt className="w-5 h-5" style={{ color: CHART_COLORS.primary[0] }} />
          <h2 className="text-lg font-semibold">Recent Transactions</h2>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search transactions..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 pr-4 py-2 rounded-lg bg-white/50 border border-white/20 focus:outline-none focus:ring-2 focus:ring-[#54bebe] focus:border-transparent placeholder-gray-400 text-sm"
          />
        </div>
      </div>

      {/* Transactions */}
      <div className="divide-y divide-white/10">
        {paginatedTransactions.map((transaction, index) => {
          const [day, month, year] = transaction.transactionDate.split('.');
          const date = new Date(parseInt(year), parseInt(month) - 1, parseInt(day));
          const isPositive = transaction.bookedAmount >= 0;
          
          return (
            <div 
              key={`${transaction.transactionId}-${index}`}
              className="p-4 hover:bg-white/5 transition-colors flex items-center justify-between group"
            >
              {/* Left side - Date and Merchant */}
              <div className="flex items-start gap-4">
                <div className="text-sm text-gray-500">
                  {format(date, 'MMM d')}
                </div>
                <div>
                  <div className="font-medium text-gray-900">
                    {getMerchantName(transaction)}
                  </div>
                  <div className="text-sm text-gray-500">
                    {transaction.transactionCategory || 'Uncategorized'}
                  </div>
                </div>
              </div>

              {/* Right side - Amount */}
              <div className="flex items-center gap-2">
                <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-sm ${
                  isPositive 
                    ? 'text-[#54bebe] bg-[#54bebe]/10'
                    : 'text-[#d7658b] bg-[#d7658b]/10'
                }`}>
                  {isPositive ? (
                    <ArrowUpRight className="w-4 h-4" />
                  ) : (
                    <ArrowDownRight className="w-4 h-4" />
                  )}
                  {formatCurrency(Math.abs(transaction.bookedAmount))}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Pagination */}
      <div className="p-4 border-t border-white/10 flex items-center justify-between bg-white/5">
        <button
          onClick={() => setPage(p => Math.max(0, p - 1))}
          disabled={page === 0}
          className="p-2 rounded-lg hover:bg-white/10 disabled:opacity-50 disabled:hover:bg-transparent transition-colors"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        
        <span className="text-sm text-gray-600">
          Page {page + 1} of {totalPages}
        </span>
        
        <button
          onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))}
          disabled={page >= totalPages - 1}
          className="p-2 rounded-lg hover:bg-white/10 disabled:opacity-50 disabled:hover:bg-transparent transition-colors"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};