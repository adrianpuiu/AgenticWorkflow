import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { Transaction } from '../../types';
import { formatCurrency } from '../../utils/formatters';

interface Props {
  transactions: Transaction[];
}

const COLORS = [
  '#22c55e', // green
  '#3b82f6', // blue
  '#f59e0b', // amber
  '#8b5cf6', // purple
  '#14b8a6', // teal
];

interface CustomTooltipProps {
  active?: boolean;
  payload?: Array<{ name: string; value: number }>;
}

const CustomTooltip: React.FC<CustomTooltipProps> = ({ active, payload }) => {
  if (!active || !payload?.length) return null;

  return (
    <div className="bg-white p-3 shadow-lg rounded-lg border border-gray-200">
      <p className="font-medium text-gray-900">{payload[0].name}</p>
      <p className="text-sm text-green-600">
        {formatCurrency(payload[0].value)}
      </p>
    </div>
  );
};

export const IncomeBreakdown: React.FC<Props> = ({ transactions }) => {
  const incomeSources = transactions
    .filter(t => t.bookedAmount > 0)
    .reduce((acc, t) => {
      let source = 'Other';
      
      // Categorize income sources based on transaction details
      if (t.transactionType?.toLowerCase().includes('salary') || 
          t.message?.toLowerCase().includes('salary') ||
          t.nameOfAccount?.toLowerCase().includes('salary')) {
        source = 'Salary';
      } else if (t.transactionType === 'Interest' || 
                 t.message?.toLowerCase().includes('interest')) {
        source = 'Interest';
      } else if (t.transactionType === 'Investment' || 
                 t.message?.toLowerCase().includes('dividend')) {
        source = 'Investments';
      }
      
      acc[source] = (acc[source] || 0) + t.bookedAmount;
      return acc;
    }, {} as Record<string, number>);

  const data = Object.entries(incomeSources)
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value);

  const total = data.reduce((sum, item) => sum + item.value, 0);

  return (
    <div className="bg-white rounded-xl shadow-sm p-6">
      <h3 className="text-lg font-semibold mb-4">Income Sources</h3>
      <div className="h-[300px]">
        <ResponsiveContainer>
          <PieChart>
            <Pie
              data={data}
              dataKey="value"
              nameKey="name"
              cx="50%"
              cy="50%"
              outerRadius={100}
              label={({ name, percent }) => 
                `${name} (${(percent * 100).toFixed(0)}%)`
              }
            >
              {data.map((_, index) => (
                <Cell 
                  key={`cell-${index}`} 
                  fill={COLORS[index % COLORS.length]} 
                />
              ))}
            </Pie>
            <Tooltip content={<CustomTooltip />} />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      </div>
      <div className="mt-4 text-sm text-gray-600">
        Total Income: {formatCurrency(total)}
      </div>
    </div>
  );
};