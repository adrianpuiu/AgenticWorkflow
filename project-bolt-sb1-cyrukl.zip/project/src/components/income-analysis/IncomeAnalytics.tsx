import React from 'react';
import { Transaction } from '../../types';
import { IncomeGrowth } from './IncomeGrowth';

interface Props {
  transactions: Transaction[];
}

export const IncomeAnalytics: React.FC<Props> = ({ transactions }) => {
  return (
    <div>
      <IncomeGrowth transactions={transactions} />
    </div>
  );
};