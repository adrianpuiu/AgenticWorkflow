import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, ReferenceLine } from 'recharts';
import { Transaction } from '../../types';
import { formatCurrency } from '../../utils/formatters';
import { CHART_COLORS } from '../../utils/colors';

interface Props {
  transactions: Transaction[];
}

interface CustomTooltipProps {
  active?: boolean;
  payload?: Array<{ name: string; value: number }>;
  label?: string;
}

const CustomTooltip: React.FC<CustomTooltipProps> = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;

  return (
    <div className="bg-white/90 backdrop-blur-sm p-4 shadow-lg rounded-lg border border-white/20">
      <p className="font-medium text-gray-900">{label}</p>
      {payload.map((item, index) => (
        <p key={index} className="text-sm" style={{ color: item.color }}>
          {item.name}: {formatCurrency(item.value)}
        </p>
      ))}
    </div>
  );
};

export const IncomeGrowth: React.FC<Props> = ({ transactions }) => {
  // Group transactions by month
  const monthlyIncome = transactions
    .filter(t => t.bookedAmount > 0)
    .reduce((acc, t) => {
      const [day, month, year] = t.transactionDate.split('.');
      const monthKey = `${month}/${year}`;
      
      if (!acc[monthKey]) {
        acc[monthKey] = {
          total: 0,
          salary: 0,
          other: 0
        };
      }
      
      const amount = t.bookedAmount;
      acc[monthKey].total += amount;
      
      // Categorize income
      if (t.message?.toLowerCase().includes('salary') || 
          t.nameOfAccount?.toLowerCase().includes('msd')) {
        acc[monthKey].salary += amount;
      } else {
        acc[monthKey].other += amount;
      }
      
      return acc;
    }, {} as Record<string, { total: number; salary: number; other: number }>);

  // Convert to array and sort by date
  const data = Object.entries(monthlyIncome)
    .map(([date, values]) => ({
      date,
      ...values
    }))
    .sort((a, b) => {
      const [aMonth, aYear] = a.date.split('/');
      const [bMonth, bYear] = b.date.split('/');
      return (parseInt(aYear) - parseInt(bYear)) || (parseInt(aMonth) - parseInt(bMonth));
    });

  // Calculate average monthly income for reference line
  const avgIncome = data.length > 0 
    ? data.reduce((sum, d) => sum + d.total, 0) / data.length 
    : 0;

  return (
    <div className="chart-container p-6">
      <h3 className="text-lg font-semibold mb-4">Income Growth</h3>
      <div className="h-[300px]">
        <ResponsiveContainer>
          <LineChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.2)" />
            <XAxis 
              dataKey="date"
              tick={{ fontSize: 12, fill: '#666' }}
              stroke="#9ca3af"
            />
            <YAxis 
              tickFormatter={(value) => formatCurrency(value).split('CZK')[0].trim()}
              stroke="#9ca3af"
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend />
            
            {avgIncome > 0 && (
              <ReferenceLine 
                y={avgIncome} 
                stroke={CHART_COLORS.primary[0]}
                strokeDasharray="3 3"
                label={{ 
                  value: 'Average Income',
                  position: 'right',
                  fill: CHART_COLORS.primary[0],
                  fontSize: 12
                }}
              />
            )}
            
            <Line
              type="monotone"
              dataKey="total"
              name="Total Income"
              stroke={CHART_COLORS.primary[0]}
              strokeWidth={2}
              dot={{ r: 4 }}
              activeDot={{ r: 6 }}
            />
            <Line
              type="monotone"
              dataKey="salary"
              name="Salary"
              stroke={CHART_COLORS.primary[3]}
              strokeWidth={2}
              dot={{ r: 4 }}
              activeDot={{ r: 6 }}
            />
            <Line
              type="monotone"
              dataKey="other"
              name="Other Income"
              stroke={CHART_COLORS.primary[6]}
              strokeWidth={2}
              dot={{ r: 4 }}
              activeDot={{ r: 6 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
      <div className="mt-4 text-sm text-gray-600 text-center">
        Shows income trends over time, broken down by source
      </div>
    </div>
  );
};