// Update chartOptions in ChartMenu.tsx to include the custom chart option:
const chartOptions: ChartOption[] = [
  {
    id: 'daily-activity',
    label: 'Daily Financial Activity',
    icon: <Activity className="w-5 h-5" />,
    description: 'Track daily income, spending, and balance',
    permanent: true
  },
  {
    id: 'expense-breakdown',
    label: 'Expense Breakdown',
    icon: <PieChart className="w-5 h-5" />,
    description: 'View expenses by category in a pie chart'
  },
  {
    id: 'category-comparison',
    label: 'Category Comparison',
    icon: <BarChart className="w-5 h-5" />,
    description: 'Compare spending across different categories'
  },
  {
    id: 'income-analysis',
    label: 'Income Analysis',
    icon: <TrendingUp className="w-5 h-5" />,
    description: 'Analyze income sources and growth'
  },
  {
    id: 'recent-transactions',
    label: 'Recent Transactions',
    icon: <Receipt className="w-5 h-5" />,
    description: 'View detailed transaction history'
  },
  {
    id: 'custom-chart',
    label: 'Custom Chart',
    icon: <Brain className="w-5 h-5" />,
    description: 'Generate custom charts using AI'
  }
];