import React, { useState } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { Transaction } from '../../types';
import { formatCurrency } from '../../utils/formatters';

interface Props {
  transactions: Transaction[];
}

interface CustomTooltipProps {
  active?: boolean;
  payload?: Array<{ name: string; value: number; payload: { color: string } }>;
}

// Shuffle array function
const shuffleArray = <T,>(array: T[]): T[] => {
  const newArray = [...array];
  for (let i = newArray.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
  }
  return newArray;
};

// Define and shuffle colors
const COLORS = shuffleArray([
  "#54bebe", "#76c8c8", "#98d1d1", "#badbdb", "#dedad2", 
  "#e4bcad", "#df979e", "#d7658b", "#c80064"
]);

const CustomTooltip: React.FC<CustomTooltipProps> = ({ active, payload }) => {
  if (!active || !payload?.length) return null;

  const { name, value, payload: { color } } = payload[0];

  return (
    <div className="bg-white/90 backdrop-blur-sm p-4 shadow-lg rounded-lg border border-white/20">
      <p className="font-medium" style={{ color }}>{name}</p>
      <p className="text-sm text-gray-600">
        {formatCurrency(value)}
      </p>
    </div>
  );
};

const CustomLegend: React.FC<any> = ({ payload }) => {
  return (
    <div className="grid grid-cols-2 gap-2 mt-4">
      {payload.map((entry: any, index: number) => (
        <div key={`item-${index}`} className="flex items-center gap-2">
          <div 
            className="w-3 h-3 rounded-full" 
            style={{ backgroundColor: entry.color }}
          />
          <span className="text-sm text-gray-600 truncate">
            {entry.value}
          </span>
        </div>
      ))}
    </div>
  );
};

export const ExpenseBreakdown: React.FC<Props> = ({ transactions }) => {
  const [activeIndex, setActiveIndex] = useState<number | undefined>();

  // Process transactions to get category totals
  const categoryTotals = transactions
    .filter(t => t.bookedAmount < 0)
    .reduce((acc, t) => {
      const category = t.transactionCategory || 'Other';
      acc[category] = (acc[category] || 0) + Math.abs(t.bookedAmount);
      return acc;
    }, {} as Record<string, number>);

  // Convert to array and sort by amount
  const data = Object.entries(categoryTotals)
    .map(([name, value], index) => ({
      name,
      value,
      color: COLORS[index % COLORS.length]
    }))
    .sort((a, b) => b.value - a.value);

  const total = data.reduce((sum, item) => sum + item.value, 0);

  const onPieEnter = (_: any, index: number) => {
    setActiveIndex(index);
  };

  const onPieLeave = () => {
    setActiveIndex(undefined);
  };

  return (
    <div className="chart-container p-6">
      <h3 className="text-lg font-semibold mb-4">Expense Breakdown</h3>
      <div className="h-[400px]">
        <ResponsiveContainer>
          <PieChart>
            <Pie
              data={data}
              dataKey="value"
              nameKey="name"
              cx="50%"
              cy="50%"
              innerRadius={80}
              outerRadius={120}
              onMouseEnter={onPieEnter}
              onMouseLeave={onPieLeave}
              activeIndex={activeIndex}
              activeShape={(props) => {
                const RADIAN = Math.PI / 180;
                const { cx, cy, midAngle, innerRadius, outerRadius, startAngle, endAngle, payload, value } = props;
                const sin = Math.sin(-RADIAN * midAngle);
                const cos = Math.cos(-RADIAN * midAngle);
                const mx = cx + (outerRadius + 30) * cos;
                const my = cy + (outerRadius + 30) * sin;
                const percent = ((value / total) * 100).toFixed(1);

                return (
                  <>
                    {/* Arc */}
                    <g>
                      <path
                        d={`M ${cx},${cy} L ${cx + innerRadius * cos},${cy + innerRadius * sin} A ${innerRadius},${innerRadius} 0 0 1 ${cx + innerRadius * Math.cos(-startAngle * RADIAN)},${cy + innerRadius * Math.sin(-startAngle * RADIAN)}`}
                        fill="none"
                        stroke={payload.color}
                      />
                      <path
                        d={`M ${cx + outerRadius * cos},${cy + outerRadius * sin} L ${mx},${my}`}
                        stroke={payload.color}
                        fill="none"
                      />
                    </g>
                    {/* Label */}
                    <text
                      x={mx + (cos >= 0 ? 1 : -1) * 12}
                      y={my}
                      textAnchor={cos >= 0 ? 'start' : 'end'}
                      fill={payload.color}
                      className="text-sm font-medium"
                    >
                      {`${payload.name} (${percent}%)`}
                    </text>
                  </>
                );
              }}
            >
              {data.map((entry, index) => (
                <Cell 
                  key={`cell-${index}`}
                  fill={entry.color}
                  stroke="rgba(255,255,255,0.2)"
                  className="transition-all duration-300 hover:brightness-110"
                />
              ))}
            </Pie>
            <Tooltip content={<CustomTooltip />} />
            <Legend content={<CustomLegend />} />
          </PieChart>
        </ResponsiveContainer>
      </div>
      <div className="mt-4 text-sm text-gray-600 text-center">
        Total Expenses: {formatCurrency(total)}
      </div>
    </div>
  );
};