import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, ReferenceLine } from 'recharts';
import { Transaction } from '../../types';
import { formatCurrency } from '../../utils/formatters';

interface Props {
  transactions: Transaction[];
}

interface CustomTooltipProps {
  active?: boolean;
  payload?: Array<{ name: string; value: number; color: string }>;
  label?: string;
}

const CustomTooltip: React.FC<CustomTooltipProps> = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;

  const income = payload.find(p => p.name === 'Income')?.value || 0;
  const expenses = Math.abs(payload.find(p => p.name === 'Expenses')?.value || 0);
  const balance = income - expenses;

  return (
    <div className="bg-white p-3 shadow-lg rounded-lg border border-gray-200">
      <p className="font-medium text-gray-900 mb-2">{label}</p>
      <div className="space-y-1">
        <p className="text-sm text-green-600">
          Income: {formatCurrency(income)}
        </p>
        <p className="text-sm text-red-600">
          Expenses: {formatCurrency(expenses)}
        </p>
        <div className="border-t border-gray-200 mt-2 pt-2">
          <p className={`text-sm font-medium ${balance >= 0 ? 'text-blue-600' : 'text-red-600'}`}>
            Balance: {formatCurrency(balance)}
          </p>
        </div>
      </div>
    </div>
  );
};

export const IncomeExpenseComparison: React.FC<Props> = ({ transactions }) => {
  // Create a map of all months in the data
  const monthSet = new Set(
    transactions.map(t => {
      const [, month, year] = t.transactionDate.split('.');
      return `${year}-${month}`;
    })
  );

  const monthlyData = Array.from(monthSet).reduce((acc, monthKey) => {
    acc[monthKey] = { income: 0, expenses: 0 };
    return acc;
  }, {} as Record<string, { income: number; expenses: number }>);

  // Aggregate transactions by month
  transactions.forEach(t => {
    const [, month, year] = t.transactionDate.split('.');
    const monthKey = `${year}-${month}`;
    
    if (t.bookedAmount > 0) {
      monthlyData[monthKey].income += t.bookedAmount;
    } else {
      monthlyData[monthKey].expenses += Math.abs(t.bookedAmount);
    }
  });

  // Format data for the chart
  const data = Object.entries(monthlyData)
    .map(([date, values]) => {
      const [year, month] = date.split('-');
      return {
        date: `${month}/${year}`,
        income: values.income,
        expenses: -values.expenses, // Make expenses negative for the chart
        balance: values.income - values.expenses
      };
    })
    .sort((a, b) => a.date.localeCompare(b.date));

  // Calculate averages for reference lines
  const avgIncome = data.reduce((sum, d) => sum + d.income, 0) / data.length;
  const avgExpenses = -data.reduce((sum, d) => sum + Math.abs(d.expenses), 0) / data.length;

  return (
    <div className="bg-white rounded-xl shadow-sm p-6">
      <h3 className="text-lg font-semibold mb-4">Income vs Expenses</h3>
      <div className="h-[400px]">
        <ResponsiveContainer>
          <LineChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis 
              dataKey="date"
              tick={{ fontSize: 12 }}
            />
            <YAxis 
              tickFormatter={(value) => formatCurrency(Math.abs(value)).split('CZK')[0].trim()}
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend />
            
            <ReferenceLine 
              y={avgIncome} 
              stroke="#22c55e" 
              strokeDasharray="3 3"
              label={{ 
                value: 'Avg Income',
                position: 'right',
                fill: '#22c55e',
                fontSize: 12
              }}
            />
            <ReferenceLine 
              y={avgExpenses} 
              stroke="#ef4444" 
              strokeDasharray="3 3"
              label={{ 
                value: 'Avg Expenses',
                position: 'right',
                fill: '#ef4444',
                fontSize: 12
              }}
            />
            
            <Line
              type="monotone"
              dataKey="income"
              name="Income"
              stroke="#22c55e"
              strokeWidth={2}
              dot={{ r: 4 }}
              activeDot={{ r: 6 }}
            />
            <Line
              type="monotone"
              dataKey="expenses"
              name="Expenses"
              stroke="#ef4444"
              strokeWidth={2}
              dot={{ r: 4 }}
              activeDot={{ r: 6 }}
            />
            <Line
              type="monotone"
              dataKey="balance"
              name="Balance"
              stroke="#3b82f6"
              strokeWidth={2}
              dot={{ r: 4 }}
              activeDot={{ r: 6 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
      <div className="mt-4 text-sm text-gray-600">
        Tracks monthly income against expenses with running balance
      </div>
    </div>
  );
};