import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { Transaction } from '../../types';
import { formatCurrency } from '../../utils/formatters';

interface Props {
  transactions: Transaction[];
}

interface CustomTooltipProps {
  active?: boolean;
  payload?: Array<{ name: string; value: number }>;
  label?: string;
}

const CustomTooltip: React.FC<CustomTooltipProps> = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;

  return (
    <div className="bg-white p-3 shadow-lg rounded-lg border border-gray-200">
      <p className="font-medium text-gray-900">{label}</p>
      {payload.map((item, index) => (
        <p 
          key={index} 
          className="text-sm"
          style={{ color: item.color }}
        >
          {item.name}: {formatCurrency(item.value)}
        </p>
      ))}
    </div>
  );
};

const COLORS = [
  '#3b82f6', // blue
  '#ef4444', // red
  '#22c55e', // green
  '#f59e0b', // amber
  '#8b5cf6', // purple
  '#ec4899', // pink
  '#14b8a6', // teal
  '#f97316', // orange
  '#64748b', // slate
];

export const AverageSpending: React.FC<Props> = ({ transactions }) => {
  // Group transactions by date and category
  const categoryData = transactions
    .filter(t => t.bookedAmount < 0)
    .reduce((acc, t) => {
      const [day, month, year] = t.transactionDate.split('.');
      const date = `${year}-${month}`;
      const category = t.transactionCategory || 'Other';
      
      if (!acc[date]) {
        acc[date] = {};
      }
      
      if (!acc[date][category]) {
        acc[date][category] = {
          total: 0,
          count: 0
        };
      }
      
      acc[date][category].total += Math.abs(t.bookedAmount);
      acc[date][category].count += 1;
      
      return acc;
    }, {} as Record<string, Record<string, { total: number; count: number }>>);

  // Calculate averages and format data for the chart
  const data = Object.entries(categoryData).map(([date, categories]) => {
    const [year, month] = date.split('-');
    const result: Record<string, number> = {
      date: `${month}/${year}`
    };
    
    Object.entries(categories).forEach(([category, { total, count }]) => {
      result[category] = total / count;
    });
    
    return result;
  }).sort((a, b) => a.date.localeCompare(b.date));

  // Get unique categories
  const categories = Array.from(
    new Set(
      transactions
        .filter(t => t.bookedAmount < 0)
        .map(t => t.transactionCategory || 'Other')
    )
  ).sort();

  return (
    <div className="bg-white rounded-xl shadow-sm p-6">
      <h3 className="text-lg font-semibold mb-4">Average Spending by Category</h3>
      <div className="h-[300px]">
        <ResponsiveContainer>
          <LineChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis 
              dataKey="date"
              tick={{ fontSize: 12 }}
            />
            <YAxis 
              tickFormatter={(value) => formatCurrency(value).split('CZK')[0].trim()}
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend />
            {categories.map((category, index) => (
              <Line
                key={category}
                type="monotone"
                dataKey={category}
                name={category}
                stroke={COLORS[index % COLORS.length]}
                strokeWidth={2}
                dot={{ r: 4 }}
                activeDot={{ r: 6 }}
              />
            ))}
          </LineChart>
        </ResponsiveContainer>
      </div>
      <div className="mt-4 text-sm text-gray-600">
        Shows the average amount spent per transaction in each category over time
      </div>
    </div>
  );
};