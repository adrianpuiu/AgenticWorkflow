import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Transaction } from '../../types';
import { formatCurrency } from '../../utils/formatters';

interface Props {
  transactions: Transaction[];
}

interface CustomTooltipProps {
  active?: boolean;
  payload?: Array<{ name: string; value: number }>;
  label?: string;
}

const CustomTooltip: React.FC<CustomTooltipProps> = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;

  return (
    <div className="bg-white p-3 shadow-lg rounded-lg border border-gray-200">
      <p className="font-medium text-gray-900">{label}</p>
      {payload.map((item, index) => (
        <p key={index} className="text-sm text-gray-600">
          {item.name}: {formatCurrency(item.value)}
        </p>
      ))}
    </div>
  );
};

export const ExpenseTrends: React.FC<Props> = ({ transactions }) => {
  const dailyExpenses = transactions
    .filter(t => t.bookedAmount < 0)
    .reduce((acc, t) => {
      const date = t.transactionDate;
      const category = t.transactionCategory || 'Other';
      
      if (!acc[date]) {
        acc[date] = {};
      }
      
      acc[date][category] = (acc[date][category] || 0) + Math.abs(t.bookedAmount);
      return acc;
    }, {} as Record<string, Record<string, number>>);

  const data = Object.entries(dailyExpenses)
    .map(([date, categories]) => ({
      date,
      ...categories
    }))
    .sort((a, b) => a.date.localeCompare(b.date));

  const categories = Array.from(
    new Set(
      transactions
        .filter(t => t.bookedAmount < 0)
        .map(t => t.transactionCategory || 'Other')
    )
  );

  const COLORS = [
    '#3b82f6', '#ef4444', '#22c55e', '#f59e0b', '#8b5cf6',
    '#ec4899', '#14b8a6', '#f97316', '#64748b'
  ];

  return (
    <div className="bg-white rounded-xl shadow-sm p-6">
      <h3 className="text-lg font-semibold mb-4">Expense Trends</h3>
      <div className="h-[300px]">
        <ResponsiveContainer>
          <AreaChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis 
              dataKey="date" 
              tick={{ fontSize: 12 }}
              interval={Math.floor(data.length / 5)}
            />
            <YAxis 
              tickFormatter={(value) => formatCurrency(value).split('CZK')[0].trim()}
            />
            <Tooltip content={<CustomTooltip />} />
            {categories.map((category, index) => (
              <Area
                key={category}
                type="monotone"
                dataKey={category}
                stackId="1"
                stroke={COLORS[index % COLORS.length]}
                fill={COLORS[index % COLORS.length]}
                name={category}
              />
            ))}
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};