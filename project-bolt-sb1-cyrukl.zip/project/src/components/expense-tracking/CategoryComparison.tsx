import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Transaction } from '../../types';
import { formatCurrency } from '../../utils/formatters';
import { CHART_COLORS } from '../../utils/colors';

interface Props {
  transactions: Transaction[];
}

interface CustomTooltipProps {
  active?: boolean;
  payload?: Array<{ name: string; value: number; payload: { color: string } }>;
}

const CustomTooltip: React.FC<CustomTooltipProps> = ({ active, payload }) => {
  if (!active || !payload?.length) return null;

  const { name, value, payload: { color } } = payload[0];

  return (
    <div className="bg-white/90 backdrop-blur-sm p-4 shadow-lg rounded-lg border border-white/20">
      <p className="font-medium" style={{ color }}>{name}</p>
      <p className="text-sm text-gray-600">
        {formatCurrency(value)}
      </p>
    </div>
  );
};

export const CategoryComparison: React.FC<Props> = ({ transactions }) => {
  // Process transactions to get category totals
  const categoryTotals = transactions
    .filter(t => t.bookedAmount < 0)
    .reduce((acc, t) => {
      const category = t.transactionCategory || 'Other';
      acc[category] = (acc[category] || 0) + Math.abs(t.bookedAmount);
      return acc;
    }, {} as Record<string, number>);

  // Convert to array and sort by amount
  const data = Object.entries(categoryTotals)
    .map(([category, amount]) => ({
      category,
      amount,
      color: CHART_COLORS.categories[category as keyof typeof CHART_COLORS.categories] || 
             CHART_COLORS.primary[Object.keys(categoryTotals).indexOf(category) % CHART_COLORS.primary.length]
    }))
    .sort((a, b) => b.amount - a.amount);

  return (
    <div className="chart-container p-6">
      <h3 className="text-lg font-semibold mb-4">Category Comparison</h3>
      <div className="h-[400px]">
        <ResponsiveContainer>
          <BarChart 
            data={data} 
            margin={{ top: 20, right: 30, left: 20, bottom: 60 }}
          >
            <CartesianGrid 
              strokeDasharray="3 3" 
              stroke="rgba(255,255,255,0.2)"
              vertical={false}
            />
            <XAxis 
              dataKey="category" 
              tick={{ fontSize: 12, fill: '#666' }}
              interval={0}
              angle={-45}
              textAnchor="end"
              height={60}
              stroke="#9ca3af"
            />
            <YAxis 
              tickFormatter={(value) => formatCurrency(value).split('CZK')[0].trim()}
              stroke="#9ca3af"
              axisLine={false}
              tickLine={false}
            />
            <Tooltip content={<CustomTooltip />} />
            <Bar 
              dataKey="amount" 
              radius={[4, 4, 0, 0]}
            >
              {data.map((entry, index) => (
                <Cell 
                  key={`cell-${index}`}
                  fill={entry.color}
                  className="transition-all duration-300 hover:opacity-80"
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
      <div className="mt-4 text-sm text-gray-600 text-center">
        Shows total spending by category
      </div>
    </div>
  );
};