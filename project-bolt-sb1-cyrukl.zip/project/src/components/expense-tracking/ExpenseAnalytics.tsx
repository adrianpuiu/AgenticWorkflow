import React from 'react';
import { Transaction } from '../../types';
import { ExpenseBreakdown } from './ExpenseBreakdown';

interface Props {
  transactions: Transaction[];
}

export const ExpenseAnalytics: React.FC<Props> = ({ transactions }) => {
  return <ExpenseBreakdown transactions={transactions} />;
};