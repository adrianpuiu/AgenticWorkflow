import React, { useEffect, useState } from 'react';
import { AlertTriangle, Brain, Info, Loader2, Settings, TrendingUp } from 'lucide-react';
import { formatCurrency } from '../utils/formatters';
import { getAIInsights, AIProvider } from '../services/aiService';
import { Transaction } from '../types';
import ReactMarkdown from 'react-markdown';
import { CHART_COLORS } from '../utils/colors';

interface Props {
  spending: number;
  income: number;
  highestCategory: {
    name: string;
    amount: number;
  };
  transactions: Transaction[];
}

export const AIInsights: React.FC<Props> = ({ spending, income, highestCategory, transactions }) => {
  const [insights, setInsights] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [provider, setProvider] = useState<AIProvider>('openai');
  
  const hasIncome = income > 0;
  const spendingRatio = hasIncome ? (spending / income) * 100 : Infinity;
  const isHighIncome = income > 250000;
  const averageDailyEarnings = hasIncome ? income / 30 : 0;

  useEffect(() => {
    const fetchInsights = async () => {
      setLoading(true);
      setError(null);
      try {
        const aiInsights = await getAIInsights(transactions, provider);
        setInsights(aiInsights);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to generate AI insights');
        console.error('AI Insights Error:', err);
      } finally {
        setLoading(false);
      }
    };

    if (transactions.length > 0) {
      fetchInsights();
    }
  }, [transactions, provider]);

  return (
    <div className="relative overflow-hidden rounded-xl shadow-xl backdrop-blur-sm border border-white/20 transition-all hover:shadow-lg"
         style={{
           background: `linear-gradient(135deg, ${CHART_COLORS.primary[0]}15, ${CHART_COLORS.primary[3]}15, ${CHART_COLORS.primary[6]}15)`
         }}>
      <div className="absolute inset-0 bg-white/40 backdrop-blur-sm" />
      
      <div className="relative p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg" style={{ backgroundColor: `${CHART_COLORS.primary[0]}15` }}>
              <Brain className="w-6 h-6" style={{ color: CHART_COLORS.primary[0] }} />
            </div>
            <h2 className="text-xl font-semibold bg-gradient-to-r from-[#54bebe] to-[#c80064] bg-clip-text text-transparent">
              AI-Powered Insights
            </h2>
          </div>
          
          <div className="flex items-center gap-2">
            <Settings className="w-4 h-4 text-gray-500" />
            <select
              value={provider}
              onChange={(e) => setProvider(e.target.value as AIProvider)}
              className="text-sm rounded-md border-0 py-1.5 pl-3 pr-8 ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-[#54bebe] bg-white/50 backdrop-blur-sm transition-all hover:bg-white/80"
            >
              <option value="openai">OpenAI (GPT-4)</option>
              <option value="xai">xAI (Grok)</option>
            </select>
          </div>
        </div>
        
        <div className="space-y-4">
          <div className="flex items-start gap-2 p-4 rounded-lg bg-white/50 backdrop-blur-sm border border-white/20">
            <Info className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: CHART_COLORS.primary[0] }} />
            <div>
              <p className="font-medium" style={{ color: CHART_COLORS.primary[0] }}>Quick Stats</p>
              <ul className="text-sm space-y-1 text-gray-600">
                <li>Monthly Income: {formatCurrency(income)}</li>
                <li>Average Daily Earnings: {formatCurrency(averageDailyEarnings)}</li>
                <li>Highest spending: {highestCategory.name} ({formatCurrency(highestCategory.amount)})</li>
                <li>Daily spending avg: {formatCurrency(spending / 30)}</li>
              </ul>
            </div>
          </div>

          {isHighIncome && (
            <div className="flex items-start gap-2 p-4 rounded-lg bg-white/50 backdrop-blur-sm border border-white/20">
              <TrendingUp className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: CHART_COLORS.primary[3] }} />
              <div>
                <p className="font-medium" style={{ color: CHART_COLORS.primary[3] }}>High Income Profile</p>
                <p className="text-sm text-gray-600">
                  Your high income profile enables additional financial opportunities.
                </p>
              </div>
            </div>
          )}

          {spendingRatio > 90 && (
            <div className="flex items-start gap-2 p-4 rounded-lg bg-white/50 backdrop-blur-sm border border-white/20">
              <AlertTriangle className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: CHART_COLORS.primary[6] }} />
              <div>
                <p className="font-medium" style={{ color: CHART_COLORS.primary[6] }}>High Spending Alert</p>
                <p className="text-sm text-gray-600">
                  Your spending is {spendingRatio === Infinity ? 'infinite' : `${spendingRatio.toFixed(1)}%`} of your income.
                </p>
              </div>
            </div>
          )}

          <div className="p-4 rounded-lg bg-white/50 backdrop-blur-sm border border-white/20">
            <h3 className="font-medium text-gray-900 mb-2">AI Analysis</h3>
            {loading ? (
              <div className="flex items-center gap-2 text-gray-600">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Analyzing your transactions...</span>
              </div>
            ) : error ? (
              <div className="text-[#d7658b] text-sm space-y-1">
                <p>{error}</p>
                <button 
                  onClick={() => setProvider(provider === 'openai' ? 'xai' : 'openai')}
                  className="text-[#54bebe] hover:underline"
                >
                  Try {provider === 'openai' ? 'xAI' : 'OpenAI'} instead
                </button>
              </div>
            ) : (
              <div className="prose prose-sm max-w-none prose-headings:text-[#54bebe] prose-a:text-[#76c8c8]">
                <ReactMarkdown>{insights || ''}</ReactMarkdown>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};