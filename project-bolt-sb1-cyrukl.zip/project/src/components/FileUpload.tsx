import React, { useState } from 'react';
import { Upload, Check } from 'lucide-react';

interface Props {
  onFileUpload: (content: string) => void;
}

export const FileUpload: React.FC<Props> = ({ onFileUpload }) => {
  const [isUploaded, setIsUploaded] = useState(false);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith('.csv')) {
      alert('Please upload a CSV file');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result;
      if (typeof text === 'string') {
        onFileUpload(text);
        setIsUploaded(true);
      }
    };
    reader.readAsText(file);
  };

  if (isUploaded) {
    return (
      <div className="bg-green-50 text-green-700 px-4 py-2 rounded-lg flex items-center gap-2 mb-6 text-sm">
        <Check className="w-4 h-4" />
        <span>Transactions loaded successfully</span>
      </div>
    );
  }

  return (
    <div className="bg-white px-4 py-2 rounded-lg shadow-sm mb-6 flex items-center justify-between">
      <div className="flex items-center gap-2">
        <Upload className="w-4 h-4 text-blue-600" />
        <span className="text-sm text-gray-600">Upload transactions file (CSV)</span>
      </div>
      
      <label className="px-4 py-1 bg-blue-50 hover:bg-blue-100 text-blue-600 rounded cursor-pointer text-sm">
        Choose File
        <input 
          type="file" 
          className="hidden" 
          accept=".csv"
          onChange={handleFileChange}
        />
      </label>
    </div>
  );
};