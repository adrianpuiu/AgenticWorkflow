import React, { useState } from 'react';
import { Brain, Loader2, Send } from 'lucide-react';
import OpenAI from 'openai';
import { Transaction } from '../../types';
import { DynamicChart } from './DynamicChart';
import { CHART_COLORS } from '../../utils/colors';

interface Props {
  transactions: Transaction[];
}

interface ChartConfig {
  type: 'line' | 'bar' | 'pie' | 'area';
  title: string;
  description: string;
  data: any[];
  config: {
    xAxis?: string;
    yAxis?: string;
    series: Array<{
      name: string;
      dataKey: string;
      color: string;
    }>;
  };
}

export const CustomChartGenerator: React.FC<Props> = ({ transactions }) => {
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [chartConfig, setChartConfig] = useState<ChartConfig | null>(null);

  const generateChart = async () => {
    setLoading(true);
    setError(null);

    try {
      const openai = new OpenAI({
        apiKey: import.meta.env.VITE_OPENAI_API_KEY,
        dangerouslyAllowBrowser: true
      });

      const response = await openai.chat.completions.create({
        model: "gpt-4-turbo-preview",
        messages: [
          {
            role: "system",
            content: `You are a data visualization expert. Generate a chart configuration based on the user's request.
            The response should be a valid JSON object with the following structure:
            {
              type: "line" | "bar" | "pie" | "area",
              title: string,
              description: string,
              data: Array<any>, // Transformed data for the chart
              config: {
                xAxis?: string,
                yAxis?: string,
                series: Array<{
                  name: string,
                  dataKey: string,
                  color: string
                }>
              }
            }
            
            Available transaction fields:
            - transactionDate: string (DD.MM.YYYY)
            - bookedAmount: number
            - transactionCategory: string
            - merchant: string
            - transactionType: string
            
            Available colors: ${JSON.stringify(CHART_COLORS.primary)}`
          },
          {
            role: "user",
            content: `Transactions data: ${JSON.stringify(transactions.slice(0, 5))}...
            
            User request: ${prompt}
            
            Generate a chart configuration that best visualizes this data according to the user's request.`
          }
        ],
        response_format: { type: "json_object" }
      });

      const config = JSON.parse(response.choices[0].message.content);
      setChartConfig(config);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate chart');
      console.error('Chart generation error:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="chart-container p-6">
      <div className="flex items-center gap-2 mb-6">
        <Brain className="w-6 h-6" style={{ color: CHART_COLORS.primary[0] }} />
        <h2 className="text-xl font-semibold">AI Chart Generator</h2>
      </div>

      <div className="mb-6">
        <div className="relative">
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe the chart you want to see (e.g., 'Show me monthly spending trends by category' or 'Compare income sources over time')"
            className="w-full h-24 px-4 py-3 rounded-lg bg-white/50 border border-white/20 focus:outline-none focus:ring-2 focus:ring-[#54bebe] focus:border-transparent resize-none"
          />
          <button
            onClick={generateChart}
            disabled={loading || !prompt.trim()}
            className="absolute bottom-3 right-3 p-2 rounded-full bg-[#54bebe] text-white disabled:opacity-50 disabled:cursor-not-allowed hover:bg-[#76c8c8] transition-colors"
          >
            {loading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <Send className="w-5 h-5" />
            )}
          </button>
        </div>

        {error && (
          <div className="mt-2 text-sm text-[#d7658b]">
            {error}
          </div>
        )}
      </div>

      {chartConfig && (
        <div className="space-y-4">
          <div>
            <h3 className="text-lg font-medium">{chartConfig.title}</h3>
            <p className="text-sm text-gray-600">{chartConfig.description}</p>
          </div>
          <DynamicChart config={chartConfig} />
        </div>
      )}
    </div>
  );
};