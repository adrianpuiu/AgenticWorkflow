import React from 'react';
import {
  LineChart, Line, BarChart, Bar, PieChart, Pie, AreaChart, Area,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell
} from 'recharts';
import { formatCurrency } from '../../utils/formatters';

interface ChartConfig {
  type: 'line' | 'bar' | 'pie' | 'area';
  title: string;
  description: string;
  data: any[];
  config: {
    xAxis?: string;
    yAxis?: string;
    series: Array<{
      name: string;
      dataKey: string;
      color: string;
    }>;
  };
}

interface Props {
  config: ChartConfig;
}

const CustomTooltip: React.FC<any> = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;

  return (
    <div className="bg-white/90 backdrop-blur-sm p-4 shadow-lg rounded-lg border border-white/20">
      {label && <p className="font-medium text-gray-900 mb-2">{label}</p>}
      <div className="space-y-1">
        {payload.map((entry: any, index: number) => (
          <div key={index} className="flex items-center gap-2">
            <div
              className="w-3 h-3 rounded-full"
              style={{ backgroundColor: entry.color }}
            />
            <span className="text-sm">
              {entry.name}: {formatCurrency(entry.value)}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export const DynamicChart: React.FC<Props> = ({ config }) => {
  const renderChart = () => {
    const commonProps = {
      data: config.data,
      margin: { top: 20, right: 30, left: 20, bottom: 5 }
    };

    const commonAxisProps = {
      xAxis: <XAxis dataKey={config.config.xAxis} />,
      yAxis: (
        <YAxis
          tickFormatter={(value) => formatCurrency(value).split('CZK')[0].trim()}
        />
      ),
      cartesianGrid: <CartesianGrid strokeDasharray="3 3" />,
      tooltip: <Tooltip content={<CustomTooltip />} />
    };

    switch (config.type) {
      case 'line':
        return (
          <LineChart {...commonProps}>
            {commonAxisProps.cartesianGrid}
            {commonAxisProps.xAxis}
            {commonAxisProps.yAxis}
            {commonAxisProps.tooltip}
            {config.config.series.map((series, index) => (
              <Line
                key={index}
                type="monotone"
                dataKey={series.dataKey}
                name={series.name}
                stroke={series.color}
                strokeWidth={2}
                dot={{ r: 4 }}
                activeDot={{ r: 6 }}
              />
            ))}
          </LineChart>
        );

      case 'bar':
        return (
          <BarChart {...commonProps}>
            {commonAxisProps.cartesianGrid}
            {commonAxisProps.xAxis}
            {commonAxisProps.yAxis}
            {commonAxisProps.tooltip}
            {config.config.series.map((series, index) => (
              <Bar
                key={index}
                dataKey={series.dataKey}
                name={series.name}
                fill={series.color}
              />
            ))}
          </BarChart>
        );

      case 'area':
        return (
          <AreaChart {...commonProps}>
            {commonAxisProps.cartesianGrid}
            {commonAxisProps.xAxis}
            {commonAxisProps.yAxis}
            {commonAxisProps.tooltip}
            {config.config.series.map((series, index) => (
              <Area
                key={index}
                type="monotone"
                dataKey={series.dataKey}
                name={series.name}
                fill={series.color}
                stroke={series.color}
                fillOpacity={0.6}
              />
            ))}
          </AreaChart>
        );

      case 'pie':
        return (
          <PieChart {...commonProps}>
            <Pie
              data={config.data}
              dataKey={config.config.series[0].dataKey}
              nameKey={config.config.xAxis}
              cx="50%"
              cy="50%"
              outerRadius={80}
              label
            >
              {config.data.map((_, index) => (
                <Cell
                  key={`cell-${index}`}
                  fill={config.config.series[0].color}
                />
              ))}
            </Pie>
            {commonAxisProps.tooltip}
          </PieChart>
        );

      default:
        return null;
    }
  };

  return (
    <div className="h-[400px] w-full">
      <ResponsiveContainer>{renderChart()}</ResponsiveContainer>
    </div>
  );
};