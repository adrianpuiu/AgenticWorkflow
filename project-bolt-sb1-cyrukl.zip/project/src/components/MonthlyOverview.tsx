import React from 'react';
import { Activity, TrendingDown, TrendingUp, Wallet } from 'lucide-react';
import { formatCurrency } from '../utils/formatters';
import { MonthlyStats } from '../types';

interface Props {
  stats: MonthlyStats;
  currentMonth: Date;
}

export const MonthlyOverview: React.FC<Props> = ({ stats, currentMonth }) => {
  const daysInMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 0).getDate();
  const averageDailyEarnings = stats.income / daysInMonth;
  const averageDailySpending = stats.spending / daysInMonth;

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div className="chart-container p-6 transition-all hover:shadow-lg">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-[#54bebe]/10 rounded-lg">
            <TrendingUp className="w-6 h-6 text-[#54bebe]" />
          </div>
          <div>
            <p className="text-sm text-gray-600">Monthly Income</p>
            <p className={`text-2xl font-bold ${stats.income >= 0 ? 'text-[#54bebe]' : 'text-[#d7658b]'}`}>
              {formatCurrency(stats.income)}
            </p>
            <p className="text-sm text-gray-500">
              Daily avg: {formatCurrency(averageDailyEarnings)}
            </p>
          </div>
        </div>
      </div>
      
      <div className="chart-container p-6 transition-all hover:shadow-lg">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-[#d7658b]/10 rounded-lg">
            <TrendingDown className="w-6 h-6 text-[#d7658b]" />
          </div>
          <div>
            <p className="text-sm text-gray-600">Monthly Spending</p>
            <p className="text-2xl font-bold text-[#d7658b]">
              {formatCurrency(stats.spending)}
            </p>
            <p className="text-sm text-gray-500">
              Daily avg: {formatCurrency(averageDailySpending)}
            </p>
          </div>
        </div>
      </div>
      
      <div className="chart-container p-6 transition-all hover:shadow-lg">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-[#98d1d1]/10 rounded-lg">
            <Wallet className="w-6 h-6 text-[#98d1d1]" />
          </div>
          <div>
            <p className="text-sm text-gray-600">Monthly Balance</p>
            <p className={`text-2xl font-bold ${stats.balance >= 0 ? 'text-[#98d1d1]' : 'text-[#d7658b]'}`}>
              {formatCurrency(stats.balance)}
            </p>
            <p className="text-sm text-gray-500">
              {stats.balance >= 0 ? 'Net Savings' : 'Net Spending'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};