import OpenAI from 'openai';
import { Transaction } from '../types';

export type AIProvider = 'openai' | 'xai';

const createOpenAIClient = (provider: AIProvider) => {
  return new OpenAI({
    apiKey: provider === 'xai' 
      ? import.meta.env.VITE_XAI_API_KEY 
      : import.meta.env.VITE_OPENAI_API_KEY,
    baseURL: provider === 'xai' ? "https://api.x.ai/v1" : undefined,
    dangerouslyAllowBrowser: true
  });
};

export async function getAIInsights(transactions: Transaction[], provider: AIProvider = 'openai') {
  const monthlySpending = Math.abs(transactions
    .filter(t => t.bookedAmount < 0)
    .reduce((sum, t) => sum + t.bookedAmount, 0));

  const monthlyIncome = transactions
    .filter(t => t.bookedAmount > 0)
    .reduce((sum, t) => sum + t.bookedAmount, 0);

  const isHighIncome = monthlyIncome > 250000;

  const categorySpending = transactions
    .filter(t => t.bookedAmount < 0)
    .reduce((acc, t) => {
      const category = t.transactionCategory || 'Unknown';
      acc[category] = (acc[category] || 0) + Math.abs(t.bookedAmount);
      return acc;
    }, {} as Record<string, number>);

  const dailySpending = transactions
    .filter(t => t.bookedAmount < 0)
    .reduce((acc, t) => {
      const date = t.transactionDate.split('.')[0];
      acc[date] = (acc[date] || 0) + Math.abs(t.bookedAmount);
      return acc;
    }, {} as Record<string, number>);

  try {
    const client = createOpenAIClient(provider);
    const completion = await client.chat.completions.create({
      messages: [
        {
          role: "system",
          content: `You are a concise financial advisor providing clear, actionable insights. Format your response in beautiful markdown with emojis. ${
            isHighIncome ? 'You specialize in high net worth financial planning.' : ''
          }`
        },
        {
          role: "user",
          content: `Analyze this financial data and provide a brief, impactful summary:
Monthly Income: ${monthlyIncome} CZK
Monthly Spending: ${monthlySpending} CZK
Category Spending: ${JSON.stringify(categorySpending)}
Daily Spending: ${JSON.stringify(dailySpending)}
Income Profile: ${isHighIncome ? 'High Income (>250,000 CZK/month)' : 'Standard Income'}

Focus on:
1. Key spending insights (2-3 bullet points)
2. One main optimization recommendation
3. One investment tip
${isHighIncome ? '4. One high-income specific strategy' : ''}`
        }
      ],
      model: provider === 'xai' ? "grok-beta" : "gpt-4-turbo-preview",
      temperature: 0.7,
      max_tokens: 500
    });

    return completion.choices[0].message.content;
  } catch (error) {
    console.error(`Error getting ${provider} insights:`, error);
    throw new Error(`Failed to get insights from ${provider}. Please try another provider or try again later.`);
  }
}