export interface Transaction {
  transactionDate: string;
  bookingDate: string;
  accountNumber: string;
  accountName: string;
  transactionCategory: string;
  accountNumberCard: string;
  nameOfAccount: string;
  transactionType: string;
  message: string;
  note: string;
  vs: string;
  ks: string;
  ss: string;
  bookedAmount: number;
  accountCurrency: string;
  originalAmount: string;
  originalCurrency: string;
  fee: string;
  transactionId: string;
  merchant: string;
  city: string;
}

export interface MonthlyStats {
  income: number;
  spending: number;
  balance: number;
}